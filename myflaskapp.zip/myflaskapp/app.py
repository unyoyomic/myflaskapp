from flask import Flask, render_template, flash, redirect, url_for, session,logging, request
#from data import Articles
from flask_mysqldb import MySQL
from wtforms import Form, StringField, TextAreaField, PasswordField, validators, RadioField, SubmitField, ValidationError
from wtforms.validators import InputRequired, Email
from passlib.hash import sha256_crypt
import MySQLdb
import mysql.connector
from functools import wraps

app = Flask(__name__)

#Config MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['USER'] = 'root'
app.config['PASSWORD'] = '123456'
app.config['MYSQL_DB'] = 'myflaskapp'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
#init MySQL
mysql = MySQL(app)

#Articles = Articles() 

# here i created a route
#Index
@app.route('/')
def index():
	return render_template('home.html')
#About
@app.route('/about')
def about():
	return render_template('about.html')
#Articles
@app.route('/articles')
def articles():
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	#Get articcles
	result = cur.execute("SELECT * FROM articles")
	articles = cur.fetchall()
	if result > 0:
		return render_template('articles.html', articles=articles)
	else:
		msg = 'No Articles Found'
		return render_template('articles.html', msg=msg)
	#Close connection
	cur.close()
#Single article
@app.route('/article/<string:id>/')
def article(id):
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	#Get articcles
	result = cur.execute("SELECT * FROM articles WHERE id = %s", [id])
	article = cur.fetchone()
	#Close connection
	cur.close()
	return render_template('article.html', article=article)
#Register Form class
class RegisterForm(Form):
	name = StringField('Name', [validators.Length(min=1, max=50)])
	username = StringField('Username', [validators.Length(min=4, max=25)])
	email = StringField('Email', [validators.Length(min=6, max=50)])
	password = PasswordField('Password', [
		validators.DataRequired(),
		validators.EqualTo('confirm', message='Password did not match!')
	])
	confirm = PasswordField('Confirm Password')
#User register
@app.route('/register', methods=['GET','POST'])
def register():
	form = RegisterForm(request.form)
	if request.method == 'POST' and form.validate():
			name = form.name.data
			email = form.email.data
			username = form.username.data
			password = sha256_crypt.encrypt(str(form.password.data))
			mysql = MySQLdb.connect(host="localhost",  
                     user="Raluca",        
                     passwd="stf01dnd", 
                     db="myflaskapp",
                     cursorclass=MySQLdb.cursors.DictCursor)   
			#Create cursor
			cur = mysql.cursor()
			#Execute query
			cur.execute("INSERT INTO users(name, email, username, password) VALUES(%s, %s, %s, %s)",(name, email, username, password))
			#Commit to DB
			mysql.commit()
			#Close connection
			cur.close()
			flash('You are now  registered and can log in', 'success')
			return redirect(url_for('login'))
			
	return render_template('register.html', form=form)

#User login
@app.route('/login', methods=['GET','POST'])
def login():
	if request.method == 'POST':
		#Get form fields
		username = request.form['username']
		password_candiate = request.form['password']
		mysql = MySQLdb.connect(host="localhost",    
                     user="Raluca",        
                     passwd="stf01dnd", 
                     db="myflaskapp",
                     cursorclass=MySQLdb.cursors.DictCursor)  
		#Create cursor
		cur = mysql.cursor()
		#Get user bt username
		result = cur.execute("SELECT * FROM users WHERE username = %s", [username])
		if result > 0:
			#get stored hash
			data = cur.fetchone()
			password = data['password']
			#compare password
			if sha256_crypt.verify(password_candiate, password):
				#Passed
				session['logged_in'] = True
				session['username'] = username
				flash('You are now logged in','success')
				return redirect(url_for('dashboard'))
			else:
				error = 'Invalid login '
				return render_template('login.html', error=error)	
			#Close connection
			cur.close()
		else:
			error = 'Username not found'
			return render_template('login.html', error=error)	
	return render_template('login.html')	
#Checked if user logged inf
def is_logged_in(f):
	@wraps(f)
	def wrap(*args, **kwargs):
		if 'logged_in' in session:
			return f(*args, **kwargs)
		else:
			flash('Unathorized, Please login','danger')
			return redirect(url_for('login'))
	return wrap
#Logout
@app.route('/logout')
@is_logged_in
def logout():
	session.clear()
	flash('You are now logged out','success')
	return redirect(url_for('login'))

#Dashboard
@app.route('/dashboard')
@is_logged_in
def dashboard():
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	#Get articcles
	result = cur.execute("SELECT * FROM articles")
	articles = cur.fetchall()
	if result > 0:
		return render_template('dashboard.html', articles=articles)
	else:
		msg = 'No Articles Found'
		return render_template('dashboard.html', msg=msg)
	#Close connection
	cur.close()
 #Article Form class
class ArticleForm(Form):
	title = StringField('Title', [validators.Length(min=1, max=200)])
	body = TextAreaField('Body', [validators.Length(min=30)])
#Add Article
@app.route('/add_article', methods=['GET','POST'])
@is_logged_in 
def add_article():
	form = ArticleForm(request.form)
	if request.method == 'POST' and form.validate():
		title = form.title.data
		body = form.body.data
		mysql = MySQLdb.connect(host="localhost",  
                     user="Raluca",        
                     passwd="stf01dnd", 
                     db="myflaskapp",
                     cursorclass=MySQLdb.cursors.DictCursor)  
		#Create cursor
		cur = mysql.cursor()
		#Execute query
		cur.execute("INSERT INTO articles(title, body, author) VALUES(%s, %s, %s)",(title, body, session['username']))
		#Commit to DB
		mysql.commit()
		#Close connection
		cur.close()
		flash('Article created', 'success')
		return redirect(url_for('dashboard'))
	return render_template('add_article.html', form=form)
#Edit Article
@app.route('/edit_article/<string:id>', methods=['GET','POST'])
@is_logged_in 
def edit_article(id):
	mysql = MySQLdb.connect(host="localhost",  
                     user="Raluca",        
                     passwd="stf01dnd", 
                     db="myflaskapp",
                     cursorclass=MySQLdb.cursors.DictCursor)  
	#Create cursor
	cur = mysql.cursor()
	#get article by id query
	result = cur.execute("SELECT * FROM articles WHERE id = %s", [id])
	article = cur.fetchone()
	#Get form
	form = ArticleForm(request.form)
	#Populate article from fields
	form.title.data = article['title']
	form.body.data = article['body']

	if request.method == 'POST' and form.validate():
		title = request.form['title']
		body = request.form['body']
		#Create cursor
		cur = mysql.cursor()
		#Execute query
		cur.execute("UPDATE articles SET title = %s, body = %s WHERE id = %s", (title, body, id))
		#Commit to DB
		mysql.commit()
		#Close connection
		cur.close()
		flash('Article Updated', 'success')
		return redirect(url_for('dashboard'))
	return render_template('edit_article.html', form=form)
@app.route('/delete_article/<string:id>', methods=['POST'])
@is_logged_in
def delete_article(id):
	mysql = MySQLdb.connect(host="localhost",  
                     user="Raluca",        
                     passwd="stf01dnd", 
                     db="myflaskapp",
                     cursorclass=MySQLdb.cursors.DictCursor)  
	#Create cursor
	cur = mysql.cursor()
	#Execute query
	cur.execute("DELETE FROM articles WHERE id = %s",[id])
	#Commit to DB
	mysql.commit()
	#Close connection
	cur.close()
	flash('Article Deleted', 'success')
	return redirect(url_for('dashboard'))

question_list = []
answer_list = []

#guestion form
@app.route('/question/<int:index>/', methods=['GET','POST'])
def question(index):
	questions = getQuestions()
	for question in questions:
		question_list.append(question['question_id'])
	answers = getQuestionAnswers(question_list[index])
	questions_lenght = len(questions)
	checked = request.form.get("option", False)
	print(checked)
	return render_template('question.html', question=questions[index]["question"], answers=answers, index=index, questions_lenght=questions_lenght)


def edit_user(request):
    form = QuestionForm(request.POST)
    form.group_id.choices = [(g.id, g.name) for g in Group.query.order_by('name')]

def getQuestions():
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	#Get questions
	cur.execute("SELECT * FROM questions")
	questions = cur.fetchall()
	#Close connection
	cur.close()
	return questions

def getQuestionAnswers( question_id ):
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	#Get answers
	cur.execute("SELECT * FROM answers WHERE question_id = %s", [question_id])
	answers = cur.fetchall()
	#Close connection
	cur.close()
	return answers

# here i start the app
# export DYLD_LIBRARY_PATH=/usr/local/mysql/lib/
if __name__ == '__main__':
	app.secret_key='secret123'
	app.run(debug=True)  