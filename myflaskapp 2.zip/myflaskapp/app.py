from flask import Flask, render_template, flash, redirect, url_for, session,logging, request
#from data import Articles
from flask_mysqldb import MySQL
from wtforms import Form, StringField, TextAreaField, PasswordField, validators, RadioField, SubmitField, ValidationError
from wtforms.validators import InputRequired, Email
from passlib.hash import sha256_crypt
import MySQLdb
import mysql.connector
from functools import wraps

app = Flask(__name__)

#Config MySQL
app.config['MYSQL_HOST'] = 'localhost'
app.config['USER'] = 'root'
app.config['PASSWORD'] = '123456'
app.config['MYSQL_DB'] = 'myflaskapp'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
#init MySQL
mysql = MySQL(app)

question_id_list = []
answers_id_list = []
answer_list = []
agent_id = 1
quizz_id = 1
questions_lenghtt = 0

#before request
@app.before_first_request
def getQuestionsOnce():
	questionss = getQuestions()
	for questionn in questionss:
		question_id_list.append(questionn['question_id'])

	questions_lenghtt = len(questionss)

#guestion form
@app.route('/question/<int:index>/', methods=['GET','POST'])
def question(index):
	questions = getQuestions()
	answers = getQuestionAnswers(question_id_list[index])
	questions_lenght = len(questions)
	percent = progressBar(questions_lenght)
	checked = request.form.get("option")
	answer_list.append(checked)
	print(answer_list,checked)
	return render_template('question.html', question=questions[index]["question"], 
		answers=answers, index=index, progress=questions_lenghtt, questions_lenght=questions_lenght)

#guestion form
@app.route('/pass_failed/', methods=['GET','POST'])
def quizEnd():
	print(answer_list)
	submitAnswers(agent_id, question_id_list, answer_list)
	return render_template('pass_failed.html')

def getQuestions():
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	#Get questions
	cur.execute("SELECT * FROM questions")
	questions = cur.fetchall()
	#Close connection
	cur.close()
	return questions

def getQuestionAnswers(question_id):
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	#Get answers
	cur.execute("SELECT * FROM answers WHERE question_id = %s", [question_id])
	answers = cur.fetchall()
	#Close connection
	cur.close()
	return answers

def getAnswersId():
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	for answer in answer_list:
		#Get answers
		cur.execute("SELECT * FROM answers WHERE answer = %s", [answer])
		answerId = cur.fetchone()
		answers_id_list.append(answerId['answer_id'])

	cur.close()

def submitAnswers(agent_id, question_id_list, answer_list):
	mysql = MySQLdb.connect(host="localhost",  
                    user="Raluca",        
                    passwd="stf01dnd", 
                    db="myflaskapp",
                    cursorclass=MySQLdb.cursors.DictCursor)    
	#Create cursor
	cur = mysql.cursor()
	getAnswersId()
	i = 0
	while i < len(question_id_list):
		#Execute query
		cur.execute("INSERT INTO agents_answers_by_questions(agent_id, question_id, answer_id, quizz_id) VALUES(%s, %s, %s, %s)",(agent_id, question_id_list[i], answers_id_list[i], quizz_id))
		i+=1

	mysql.commit()
	cur.close()

def progressBar(questions_lenghtt):
	percent = 100 / questions_lenghtt
	return percent


if __name__ == '__main__':
	app.secret_key='secret123'
	app.run(debug=True)  